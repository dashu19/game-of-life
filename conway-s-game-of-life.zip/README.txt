A Pen created at CodePen.io. You can find this one at https://codepen.io/dashu19/pen/dLRXJG.

 Implementing Conway's Game of Life as an exercise to learn JavaScript and React!